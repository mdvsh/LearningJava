public class Testq2
{
    public Testq2()
    {
		Fraction m = new Fraction(3,2) ;
		m.displayGraphicalRepresentation();
 

    }
}
