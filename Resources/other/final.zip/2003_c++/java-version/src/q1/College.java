
public class College
{

    public final static String NORTHEAST = "Northeast";
    public final static String SOUTHEAST = "Southeast";
    public final static String NORTHWEST = "Northwest";
    public final static String MIDWEST   = "Midwest";
    public final static String SOUTHWEST = "Southwest";
    public final static String WEST      = "West";    
    public final static String SOUTH     = "South";
    

    // returns name of this college
    public String getName()
    {
       /* implementation not shown */
    }

    // returns region of this college
    public String getRegion()
    {
       /* implementation not shown */
    }

    // returns tuition of this college
    public int getTuition()
    {
       /* implementation not shown */
    }

    // set tuition for this college to newTuition
    public void setTuition(int newTuition)
    {
       /* implementation not shown */
    }
}
